::: interactions.models.internal.protocols
