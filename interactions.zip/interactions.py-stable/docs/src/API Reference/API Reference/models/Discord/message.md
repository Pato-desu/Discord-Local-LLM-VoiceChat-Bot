::: interactions.models.discord.message
