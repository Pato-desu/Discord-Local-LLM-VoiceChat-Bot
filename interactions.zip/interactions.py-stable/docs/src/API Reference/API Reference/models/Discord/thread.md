::: interactions.models.discord.thread
