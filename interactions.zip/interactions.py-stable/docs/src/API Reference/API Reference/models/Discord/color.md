::: interactions.models.discord.color
