::: interactions.models.discord.poll
