::: interactions.models.discord.base
