::: interactions.models.discord.entitlement
