::: interactions.models.discord.asset
